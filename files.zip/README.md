# KL Attendance Tracker

A beautiful attendance dashboard + AI assistant for KL University students.  
**Frontend** → GitHub Pages &nbsp;|&nbsp; **Backend** → Render (free tier)

---

## 🚀 Deploy in 5 Minutes

### 1. Backend — Render

1. Fork/push the `backend/` folder to a GitHub repo (or use the whole repo).
2. Go to [render.com](https://render.com) → **New Web Service** → connect your repo.
3. Set:
   - **Root Directory**: `backend`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
4. Add **Environment Variable**:
   - `ANTHROPIC_API_KEY` = your Claude API key (get one at console.anthropic.com)
5. Deploy. Copy your Render URL (e.g. `https://kl-attendance-backend.onrender.com`).

### 2. Frontend — GitHub Pages

1. Open `frontend/index.html`.
2. Find this line near the bottom:
   ```js
   const API_BASE = "https://kl-attendance-backend.onrender.com";
   ```
3. Replace it with your actual Render URL.
4. Push `frontend/` to a GitHub repo.
5. Go to repo **Settings → Pages → Deploy from branch → main / root (or /docs)**.
6. Done! Your site is live at `https://yourusername.github.io/your-repo/`.

---

## ⚙️ How It Works

```
Browser → POST /api/login-attendance → Backend (Render)
                                         ├─ GET  newerp.kluniversity.in  (fetch CSRF)
                                         ├─ POST newerp.kluniversity.in  (login)
                                         ├─ GET  attendance register page
                                         └─ Parse HTML → return JSON

Browser → POST /api/chat → Backend → Anthropic Claude API → reply
```

- **No data stored** anywhere. Session lives only in the browser's memory.
- Closing/refreshing the page clears everything.
- Credentials are only held in RAM for the duration of the request, then discarded.

---

## 📁 Project Structure

```
kl-tracker/
├── backend/
│   ├── app.py            ← Flask proxy server
│   ├── requirements.txt
│   └── render.yaml       ← Render config (optional)
└── frontend/
    └── index.html        ← Single-file frontend (deploy to GitHub Pages)
```

---

## 🔑 Environment Variables (Render)

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | Optional | Enables AI chat. Get free at console.anthropic.com |

---

## ⚠️ Notes

- Render free tier **spins down after 15 min of inactivity**. First load may take ~30s to wake up.
- If the ERP layout changes, the parser in `app.py` → `parse_attendance()` may need updating.
- The `/api/login-attendance` endpoint uses a real browser session (requests + BeautifulSoup) to log in and scrape — no credentials are stored.
